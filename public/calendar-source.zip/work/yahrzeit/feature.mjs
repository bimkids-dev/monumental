import {HDate, HebrewCalendar, GeoLocation, Zmanim} from '@hebcal/core';

// Calendar calculations: Hebcal 5.9.0 (GPL-2.0), bundled for offline use.
// Geographic reference: central Bridgetown, sea level; no device geolocation.
const ZONE = 'America/Barbados';
const location = new GeoLocation('Bridgetown, Barbados', 13.1, -59.6167, 0, ZONE);
const partsFormat = new Intl.DateTimeFormat('en-GB', {timeZone: ZONE, year:'numeric', month:'numeric', day:'numeric'});
const timeFormat = new Intl.DateTimeFormat('en-GB', {timeZone: ZONE, hour:'numeric', minute:'2-digit', hour12:true});
const dateFormat = new Intl.DateTimeFormat('en-GB', {timeZone: ZONE, weekday:'long', day:'numeric', month:'long', year:'numeric'});
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const monthNumbers = {nisan:1,nissan:1,iyar:2,yiar:2,yeiar:2,sivan:3,sevan:3,tamuz:4,tammuz:4,tamus:4,av:5,ab:5,menahem:5,elul:6,elel:6,tishrei:7,tishri:7,tisri:7,tisry:7,cheshvan:8,heshvan:8,hesvan:8,marcheshvan:8,kislev:9,kisliv:9,tevet:10,tebeth:10,tebet:10,shevat:11,shvat:11,shebat:11,sebat:11,adar:12,veadar:13};

export function calendarAt(now = new Date()) {
  if (!Number.isFinite(now.getTime())) throw new Error('Invalid device clock');
  const parts = Object.fromEntries(partsFormat.formatToParts(now).filter(p => p.type !== 'literal').map(p => [p.type, Number(p.value)]));
  // Constructor deliberately uses the host's local date fields: Zmanim interprets
  // these fields in the explicitly supplied Barbados timezone.
  const civilDate = new Date(parts.year, parts.month-1, parts.day, 12);
  const sunset = new Zmanim(location, civilDate, false).sunset();
  if (!Number.isFinite(sunset.getTime())) throw new Error('Sunset unavailable');
  const afterSunset = now.getTime() >= sunset.getTime();
  let hebrew = new HDate(civilDate);
  if (afterSunset) hebrew = hebrew.next();
  const nextSunset = afterSunset ? new Zmanim(location, new Date(parts.year, parts.month-1, parts.day+1, 12), false).sunset() : sunset;
  return {hebrew, sunset, nextSunset, afterSunset, civilLabel:dateFormat.format(now), sunsetLabel:timeFormat.format(sunset)};
}

export function parseDates(record) {
  const text = String(record.hebrew_date || '').trim();
  const dates = [];
  // Use only the indexed Hebrew death-date field, never unrelated dates inside
  // an epitaph, a relative's biography, or an automatically converted civil date.
  const re = /\b(?:(5\d{3})\s+)?(\d{1,2})\s+([A-Za-z]+)(?:\s+(II|I|1|2)\b)?/g;
  for (const match of text.matchAll(re)) {
    let month = monthNumbers[match[3].toLowerCase()];
    if (!month) continue;
    const day = Number(match[2]);
    if (day < 1 || day > 30) continue;
    const year = match[1] ? Number(match[1]) : (record.hebrew_year || null);
    const explicitAdar = month === 13 || (month === 12 && Boolean(match[4]));
    if (month === 12 && ['II','2'].includes(match[4])) month = 13;
    const ambiguousAdar = month === 12 && !explicitAdar && (!year || HDate.isLeapYear(year));
    if (year && !ambiguousAdar && (month > HDate.monthsInYear(year) || day > HDate.daysInMonth(month, year))) continue;
    const candidate = {day,month,year,ambiguousAdar,asPrinted:match[0]};
    dates.push(candidate);
    // The register sometimes adds a conflicting day with no repeated month.
    const suffix = text.slice(match.index + match[0].length);
    const br = suffix.match(/^\s*\(B\.R\.\s*(\d{1,2})\)/i);
    if (br && Number(br[1]) <= 30) dates.push({...candidate,day:Number(br[1]),asPrinted:'B.R. '+br[1]+' '+match[3]});
  }
  // These two festival descriptions identify a definite day in the diaspora.
  if (/last day of Pesah/i.test(text)) dates.push({year:record.hebrew_year,month:1,day:22,asPrinted:text});
  if (/4th day of Passover/i.test(text)) dates.push({year:record.hebrew_year,month:1,day:18,asPrinted:text});
  const unique = [...new Map(dates.map(d => [[d.year,d.month,d.day].join('/'),d])).values()];
  return unique.map(d => ({...d, disputed:unique.length>1 || /\[!\]|\[sic\]/i.test(text)}));
}

export function anniversaries(date, targetYear, adarConvention = 'II') {
  if (date.year && targetYear <= date.year) return [];
  if (date.ambiguousAdar) {
    const months = HDate.isLeapYear(targetYear) ? [12,13] : [12];
    return months.filter(m=>date.day<=HDate.daysInMonth(m,targetYear)).map(m=>new HDate(date.day,m,targetYear));
  }
  if (!date.year) {
    const m = date.month === 13 && !HDate.isLeapYear(targetYear) ? 12 : date.month;
    return date.day <= HDate.daysInMonth(m,targetYear) ? [new HDate(date.day,m,targetYear)] : [];
  }
  if (date.month === 12 && !HDate.isLeapYear(date.year) && HDate.isLeapYear(targetYear) && adarConvention === 'II') return [new HDate(date.day,13,targetYear)];
  const anniversary = HebrewCalendar.getYahrzeit(targetYear, new HDate(date.day,date.month,date.year));
  return anniversary ? [anniversary] : [];
}

export function findMatches(records, today, adarConvention = 'II') {
  return records.flatMap(record => {
    const matching = parseDates(record).filter(d => anniversaries(d,today.getFullYear(),adarConvention).some(a=>a.abs()===today.abs()));
    return matching.length ? [{record,dates:matching,uncertain:record.needs_review || matching.some(d=>d.disputed||d.ambiguousAdar)}] : [];
  }).sort((a,b)=>a.record.display_name.localeCompare(b.record.display_name));
}

// The next three Hebrew days, excluding today; each day uses its own year.
// Advancing HDate (rather than adding 24 hours) also handles Rosh Hashanah.
export function findUpcoming(records, today, adarConvention = 'II', days = 3) {
  const upcoming = [];
  let date = today;
  for (let i = 0; i < days; i++) {
    date = date.next();
    upcoming.push({hebrew:date,matches:findMatches(records,date,adarConvention)});
  }
  return upcoming;
}

function civilDay(date) {
  const greg = date.greg();
  return new Date(Date.UTC(greg.getFullYear(),greg.getMonth(),greg.getDate(),12));
}
const upcomingFormat = new Intl.DateTimeFormat('en-GB', {timeZone:ZONE,weekday:'short',day:'numeric',month:'short'});
const rangeFormat = new Intl.DateTimeFormat('en-GB', {timeZone:ZONE,day:'numeric',month:'short',year:'numeric'});

export function mount(records, openRecord) {
  const $ = id => document.getElementById(id);
  let timer, key = '';
  function update(force=false) {
    clearTimeout(timer);
    try {
      const now = new Date(), state = calendarAt(now), hd = state.hebrew;
      const convention = $('yahrzeitAdar').value;
      const newKey = [hd.abs(),state.civilLabel,state.afterSunset,convention].join('|');
      if (force || newKey !== key) {
        key = newKey;
        const matches = findMatches(records,hd,convention);
        $('yahrzeitDate').textContent = hd.toString();
        $('yahrzeitHebrew').textContent = hd.renderGematriya();
        $('yahrzeitCivil').textContent = state.civilLabel;
        $('yahrzeitLocation').textContent = 'Bridgetown, Barbados · '+(state.afterSunset?'After sunset; next Hebrew day.':'Changes at sunset ≈ '+state.sunsetLabel+'.');
        $('yahrzeitSummary').textContent = matches.length ? matches.length+' matching '+(matches.length===1?'record':'records')+' · select a name to read the full entry' : 'No recorded death dates match today’s Hebrew date.';
        $('yahrzeitList').innerHTML = matches.map(({record:r,uncertain})=>'<li><a class="yahrzeit-link" href="#record-'+encodeURIComponent(r.id)+'" data-yahrzeit-record="'+esc(r.id)+'">'+esc(r.display_name)+'<span aria-hidden="true">↗</span></a><span class="yahrzeit-source">'+esc(r.hebrew_date)+' · p. '+esc(r.source_page)+(uncertain?' · Review':'')+'</span></li>').join('');
        const upcoming = findUpcoming(records,hd,convention);
        $('upcomingRange').textContent = 'Next 3 Hebrew days · '+rangeFormat.format(civilDay(upcoming[0].hebrew))+' – '+rangeFormat.format(civilDay(upcoming[upcoming.length-1].hebrew));
        const daysWithMatches = upcoming.filter(day=>day.matches.length);
        $('upcomingList').innerHTML = daysWithMatches.length ? upcoming.map(({hebrew,matches})=>'<section class="upcoming-day"><h3>'+esc(upcomingFormat.format(civilDay(hebrew)))+'<span>'+esc(hebrew.toString())+'</span></h3>'+(matches.length?'<ul>'+matches.map(({record:r,uncertain})=>'<li><a href="#record-'+encodeURIComponent(r.id)+'" data-yahrzeit-record="'+esc(r.id)+'">'+esc(r.display_name)+'</a><span class="sub">'+esc(r.monument_number?'M.I. '+r.monument_number:r.id)+' · p. '+esc(r.source_page)+(uncertain?' · Review':'')+'</span></li>').join('')+'</ul>':'<p class="sub">No recorded matches.</p>')+'</section>').join('') : '';
        $('upcomingEmpty').hidden = daysWithMatches.length !== 0;
      }
      timer = setTimeout(()=>update(),Math.max(250,Math.min(60000,state.nextSunset.getTime()-Date.now()+100)));
    } catch (error) {
      $('yahrzeitDate').textContent='Date unavailable';
      $('yahrzeitSummary').textContent='Today’s Hebrew date could not be calculated. Please check your device’s date and time, then reload.';
      $('yahrzeitList').innerHTML='';
      $('upcomingRange').textContent='Dates unavailable';
      $('upcomingList').innerHTML='';
      $('upcomingEmpty').hidden=true;
      console.error('Yahrzeit date calculation:',error);
    }
  }
  $('remembrance').addEventListener('click',event=>{
    const link=event.target.closest('[data-yahrzeit-record]');
    if (!link || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    openRecord(link.dataset.yahrzeitRecord);
  });
  $('yahrzeitAdar').addEventListener('change',()=>update(true));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)update()});
  window.addEventListener('focus',()=>update());
  update();
}
