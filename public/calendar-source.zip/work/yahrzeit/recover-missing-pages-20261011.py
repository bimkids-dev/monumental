"""One-time, photo-checked recovery of Shilstone pp. 40–41 and 96–97.

Source photographs: IMG_1056–IMG_1060.jpeg, supplied 11 October 2026.
This migration preserves existing record IDs, including the former p.42 fragment.
Uncertain readings and conflicting dates are recorded explicitly, never inferred.
"""
from pathlib import Path
import copy, json, re

ROOT = Path(__file__).resolve().parents[2]
TEMPLATE = ROOT / 'work/yahrzeit/baseline/Jewish_Barbados_Index.html'
original = TEMPLATE.read_text()
def embedded(name):
    return json.loads(re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>', original, re.S).group(1))
db, master = embedded('database'), embedded('masterData')
assert db['record_count'] == len(db['records']) == 608, 'Migration already applied or source changed'
old_records = copy.deepcopy(db['records'])
records = {r['id']:r for r in db['records']}
old_pages = copy.deepcopy(master['pages'])

pages = {
'40': '''S A / De la Malograda Honesta y Virtuoza / ESTER RACHEL Muger que Fue de / BENIAMIN GOMEZ Fallesio de Edad de / 16 Annos en Viernes 20 Kisleu 5495 / que Cor- responde a 15 Novembro 1733 / S B A G D G
יציר חומר אסיר יצר    כמו נחש יסיתך
זכור מות וצלמות    ביום [מותם?] יהתך
התתפאר ואחז ושאר    בתוך קבר ישיתך
[וחוניחם?] ותניחם    ותפר את בריתך
... חצי ימים    ותעזוב מחציתך
... אנוש נכאה    וכזאת אחריתך
[Editorial note: the Hebrew poem is printed in two columns, paired here by line. Two uncertain word readings are marked with bracketed question marks. Historical spellings are retained.]
Burial Register: 5494 20 Kislev 1733 15 Nov Ester Rachel wife of Benjamin Gomes aged 16 years.

72 Child’s small stone.
Sa/ Do Anjo Aaron / Filho de Benjamin / & Ester Nunes que / Dˢ. Foy Servido Re- / colher para sy em / 5 fʳᵃ. 13 de Yiar 5509 / que Corresponde a 20 Abril 1749 de / Idade de 15 Mezes / & 8 Dias.
Burial Register: 5509 13 Yiar 1749 20 April Aaron child of Benjamin & Ester Nunes aged 1 yr 3 mos & 8 days.

East of Wall, five large ledgers.

73 Broken in three parts and almost illegible
מצבת
קבורת המאושרה הצנועה והנכבדה
אשת הגביר
לחדש תשרי שנת
תנצבה
Da Bemaventur../ Sᴿᴬ Angela M..../ Jahacob Massiah /''',
'41': '''4 de Tisri..... / Correspon......
Burial Register: 5484 4 Tisri 1723 20 September, Angel wife of Jacob Massiah.

74 מצבת
קבורת הכבודה והצנועה מרת
אסתר זוגתו של הגביר כהיר דוד
אבוהב פורטאדו נלע׳ יום כ לחדש
תשרי התפח
S A / Da Bemaventurada & / Virtuosa ESTER Mulher que / foy de DAVID ABOAD FURTADO / que Recolheu Deos para / Sua Senta Gloria Em 20 / Tisry 5488: que são 21 Setemb / re 1727: de Idade de 33 Annos / S B A G D G
Burial Register: 5488 20 Tisri 1728 24 September Ester wife of David Aboab Furtado aged 33 years.

75 Around the sides and top :-
HERE LYETH INTERR’D THE BODY OF MR. DAVID ABOAB FURTADO MERCHANT WHO DEPARTED THIS LIFE Yᵉ 27 OF JUNE 1742.
בשנת ויקרבו ימי דוד למות לפק.
פרח דודי לעדן מוכנה
לאבואב אנשי אמונה
פורת בנים כמתנה שכינה
דום כי נסעת לעם נאמנה
[Editorial note: selected letters are marked or underlined in the printed Hebrew verse and chronogram; this plain-text transcription preserves the letters but not those typographic marks.]
S A / Do Bemaventurado y / Honrado Sʳ. DAVID / ABOAB FURTADO q / Recolheo Dˢ Em Sua / Gloria Em 14 Sivan / 5502 Corresponde 27 / Junio 1742.''',
'96': '''Burial Register: 5442 [sic!] 22 Ab Rebecca Valverde (child).

243 DE BEM. AUNTURADA / ESTER GAON QU .... / RE- COLLYDA . AS.... / POUOS . EM. 21. DE .... Y / ANO. 5427.
Burial Register: 5427 21 Tisri (1666) Ester Gaon.

Working towards Magazine Lane :-
244 Small stone much flaked, inscription illegible.

245 Almost indecipherable.
- - Da Bemaventurada ...... . Don / zela DEBORAH BURGOS Em 2.....
Possibly entered in Burial Register as 5448 23 Tisri David Burgos.

246 - - DO BEM AVENTVRA / DO VARAO SELOMOH / TINOCO QVE FOY / APANHADO ASEVS / POVOS EM 24 DE / KISLEV A 5448.
Burial Register: 5448 24 Kislev Soloman Tinoca.

247 - - DA YNCURTADA DONZELA / RAHEL ESTER HENRI- QUES QVE / FALECV EM 11 DE SEBAT / ANNO 5448 / SUA ALMA GOZE DA GLORIA. /
תנצבה
Burial Register: 5448 11 Sebat Rachel Ester Henriques.

248 - - DE ARON GABAY RISSON QUE FALECEU EM 11 .... 5448.''',
'97': '''תנצבה
Burial Register: 5448 1 Yiar Aaron Gabay Risson.

249 Broken in two pieces, and very worn.

250 DO BEM. AVENTVRADO / VARAÕ DAVID YSRAEL Q̃ / FALECEV EM 21 DE TANVS / ANNO 5449./ SVA ALMA GOZE DA GLORIA.
תנצבה
Burial Register: 5449 21 Tamus, David Israel.

251 DO YLVSTRE / VARAÕ HONRADO / & SVBLYNE DN / EPHAIM YESVRVN / HENRIQUES / FALECEO EM 19 / E TISRY DO ANO / 5450 DA CRIACAO / DO MUNDO / SUA ALMA GOZE / DA GLORIA.
Burial Register: 5450 19 Tisri Ephraim Yeshurun Henriques.

252 Sᴬ / Do yncurtado Eynsigne / mancebo Abraham de / medina que Rendeu A alma / A seu Criador em 11 de / Nisan anno 5452 / Sua Alma Goze de Gloria.
Burial Register: 5452 11 Nisan Abraham de Medina.

253 In angle of wall near warehouse :-
מצבת
קבורת הילדה אסתר
בת אברהם ורבקה ...
ביום כד לחדש אייר
שנת [החסה?]
[Editorial note: the final Hebrew year is not confidently legible in this photograph; החסה is a tentative literal reading, not a resolved calendar year. The name Ester, parents Abraham and Rebecca, and day 24 Iyar are legible. No surname or numeric year has been inferred.]'''
}
master['pages'].update(pages)

# Recheck the overlapping pages without duplicating their existing records.
master['pages']['42'] = old_pages['42'].replace('23 Septembr Judith','23 September Judith')
master['pages']['43'] = old_pages['43'].replace('נונים שילדה','נוניש שילדה')
master['pages']['101'] = old_pages['101']
master['pages']['102'] = old_pages['102'].replace('De le bein /','De la bein /')
master['pages']['103'] = old_pages['103']
master['pages']['plate opposite 101'] = 'View of the exterior of the Synagogue. (1927).\n[Editorial note: this is an unnumbered illustration facing printed page 101, confirmed in IMG_1059.jpeg.]'
master['pages'].pop('plate-101', None)  # unused duplicate caption, not an additional page
for n in ['99','100']:
    master['pages'][n] = '[Editorial pagination note: no page bearing the printed number '+n+' is visible in the supplied photographs. An unnumbered illustration faces page 101. Whether '+n+' is a blank, illustration leaf, or other pagination cannot be established from these photographs; no missing inscription text is asserted or invented.]'
idx = master['order'].index('plate opposite 101')
master['order'][idx:idx] = ['99','100']
master['page_status'] = {'40':'transcribed','41':'transcribed','96':'transcribed','97':'transcribed','99':'pagination unverified','100':'pagination unverified','128':'blank as recorded'}
master['supplemental_photographs'] = {
    'IMG_1056.jpeg':['40','41'], 'IMG_1057.jpeg':['42','43'],
    'IMG_1058.jpeg':['96','97'], 'IMG_1059.jpeg':['plate opposite 101','101'],
    'IMG_1060.jpeg':['102','103']
}
scope = ('Photographed text through page 183, including pages 40–41 and 96–97 supplied on 11 October 2026. '
         'The unnumbered plate facing page 101 is included; printed page numbers 99–100 remain unverified. '
         'Records are source entries, not a count of unique people.')
db['scope'] = scope
master['editorial_note'] = '''E. M. SHILSTONE — MASTER TRANSCRIPTION OF SUPPLIED PHOTOGRAPHS

Scope: cover, photographed preliminary pages and plates, and supplied numbered pages through 183. The previously missing pages 40–41 and 96–97 were added from photographs supplied on 11 October 2026. The overlapping pages 42–43 and 101–103 were checked; their entries are not duplicated. The unnumbered illustration facing page 101 is included with its printed caption. No photographed page bears the number 99 or 100: these numbers have editorial pagination notices, not invented transcriptions. Their precise status remains unverified. Page 128 is recorded as blank. The later printed indexes (185 onward) have not been supplied. Repeated photographs are represented once. Earlier transcriptions of pages 174–183 are incorporated in printed order.

Editorial method: historical spelling, [sic], lacunae and conflicting dates are retained. Slashes in epitaphs represent the printed inscription line divisions. Hebrew is stored in logical Unicode order and displayed right to left. This transcribes Shilstone’s printed text, not the gravestones afresh. Bracketed editorial notes are distinguished from source text. Uncertain letters are marked, not silently completed. The Hebrew poem continuing M.I. 71 on p.40 and the year in M.I. 253 on p.97 retain explicit reading cautions. The latter is indexed by its legible day and month, without an inferred year. Selected-letter chronogram typography is described where it cannot be retained in plain text. Conflicts between an inscription and a quoted Burial Register entry remain visible. A tentative attribution of a register entry is not treated as a confirmed identity or death date.

'''

def take(page, number, next_number=None):
    text = master['pages'][str(page)]
    match = re.search(r'(?m)^'+str(number)+r' ', text)
    assert match, (page,number)
    text = text[match.end():]
    if next_number is not None:
        text = text.split('\n\n'+str(next_number)+' ',1)[0]
    return text.strip()

def metadata(r):
    text = r['transcription']
    r['hebrew_transcription'] = '\n'.join(line for line in text.splitlines() if re.search(r'[\u0590-\u05ff]',line) and not line.startswith('[Editorial'))
    r['register_extracts'] = re.findall(r'(?m)^Burial Register: (.*)$',text)
    r['date_values_as_printed'] = sorted(set(int(y) for y in re.findall(r'\b(?:1[5-9]\d{2}|20\d{2}|5\d{3})\b',text)))
    r['civil_sort'], r['hebrew_sort'] = r.get('civil_year'), r.get('hebrew_year')

def provenance(r, filename, page_numbers):
    r['source_images'] = list(dict.fromkeys((r.get('source_images') or [r['image_filename']])+[filename]))
    r['source_pages'] = list(dict.fromkeys(page_numbers))
    r['source_page'] = r['source_pages'][0]
    r['verification_note'] = 'Checked against additional photograph '+filename+' supplied 11 October 2026.'

def new_record(number, name, surname, given, text, page_numbers, filename, **extra):
    r = {k:None for k in records['MI-71']}
    r.update(id='MI-'+str(number),name_as_recorded=name,display_name=name,normalized_name=name,
             surname=surname,surname_as_recorded=surname,given_names=given,
             surname_basis='Name or family relationship explicitly recorded; no maiden surname inferred.',
             cemetery='Nidhe Israel, Bridgetown',section='A',image_filename=filename,
             source_title=records['MI-71']['source_title'],source_author='E. M. Shilstone',
             source_page=page_numbers[0],source_pages=page_numbers,source_section='Burial ground enclosure A',
             record_type='Monumental inscription',monument_number=str(number),transcription=text,
             aliases=[name],source_urls=[],cross_references=[],needs_review=False,
             date_basis='Quoted Burial Register entry where securely associated; inscription conflicts retained in full transcription.')
    r.update(extra)
    metadata(r);provenance(r,filename,page_numbers)
    assert r['id'] not in records
    records[r['id']] = r
    return r

# Complete the two existing entries that previously ended at a missing page.
r=records['MI-71']
r['transcription'] += '\n'+pages['40'].split('\n\n72 ',1)[0]
r.update(death_date='1733 15 November',civil_year=1733,hebrew_date='5494 20 Kislev',hebrew_year=5494,
         age='16 years',inscription_language='Hebrew, Spanish',relationships='Ester Rachel, wife of Benjamin Gomes (Gomez in the inscription).',
         aliases=['Ester Rachel Gomes','Ester Rachel Gomez','Esther Rachel Gomes'],needs_review=True,
         notes='The inscription prints 20 Kisleu 5495 and 15 November 1733; the quoted register gives 20 Kislev 5494, 15 November 1733. The indexed date follows the register. Two words in the Hebrew poem are explicitly marked as uncertain readings.')
provenance(r,'IMG_1056.jpeg',[39,40]);metadata(r)

new_record(72,'Aaron Nunes','Nunes','Aaron',take(40,72,73).split('\n\nEast of Wall, five large ledgers.',1)[0],[40],'IMG_1056.jpeg',
    death_date='1749 20 April',civil_year=1749,hebrew_date='5509 13 Yiar',hebrew_year=5509,age='1 yr 3 mos & 8 days',
    relationships='Child of Benjamin and Ester Nunes; inscription gives 15 months and 8 days.',inscription_language='Portuguese')
new_record(73,'Angela Massiah','Massiah','Angela',take(40,73)+'\n'+pages['41'].split('\n\n74 ',1)[0],[40,41],'IMG_1056.jpeg',
    death_date='1723 20 September',civil_year=1723,hebrew_date='5484 4 Tisri',hebrew_year=5484,
    relationships='Angel, wife of Jacob Massiah, in the quoted register; inscription reads Angela and Jahacob Massiah.',
    inscription_language='Hebrew, Portuguese',aliases=['Angela Massiah','Angel Massiah'],needs_review=True,
    notes='Shilstone describes the stone as broken in three parts and almost illegible. Fragmentary inscription and the quoted register are retained separately.')
new_record(74,'Ester Aboab Furtado','Aboab Furtado','Ester',take(41,74,75),[41],'IMG_1056.jpeg',
    death_date='1728 24 September',civil_year=1728,hebrew_date='5488 20 Tisri',hebrew_year=5488,age='33 years',
    relationships='Wife of David Aboab Furtado; Portuguese inscription spells the husband’s name DAVID ABOAD FURTADO.',
    hebrew_name='אסתר',inscription_language='Hebrew, Portuguese',aliases=['Ester Aboab Furtado','Esther Aboab Furtado','Ester Aboad Furtado'],
    needs_review=True,notes='The inscription gives 20 Tisry 5488 and 21 September 1727; the register quotes 20 Tisri 5488 and 24 September 1728. These conflicting dates are preserved; the indexed date follows the quoted register.')

# Upgrade the existing continuation in place; retain its ID so old record links work.
r=records['MI-fragment-42']
r.update(name_as_recorded='David Aboab Furtado',display_name='David Aboab Furtado',normalized_name='David Aboab Furtado',
         surname='Aboab Furtado',surname_as_recorded='Aboab Furtado',given_names='David',monument_number='75',
         transcription=take(41,75)+'\n'+master['pages']['42'].split('\n\n76 ',1)[0],
         inscription_language='Hebrew, Portuguese, English',hebrew_name='דוד',
         aliases=['David Aboab Furtado','David Aboab Furtado [continuation]'],needs_review=False,
         notes='The former page-42 continuation is now joined to M.I. 75 on page 41. Its existing record ID is retained for saved links. The printed Hebrew chronogram has selected-letter marks not reproduced in plain text.')
provenance(r,'IMG_1056.jpeg',[41,42]);provenance(r,'IMG_1057.jpeg',[41,42]);metadata(r)

r=records['MI-242']
r['transcription'] += '\n'+pages['96'].split('\n\n243 ',1)[0]
r.update(hebrew_date='5442 [sic] 22 Ab',hebrew_year=5442,age='child',relationships='Daughter of AB and Jael Valverde, as written in the inscription.',
         inscription_language='Portuguese',aliases=['Ribcah Valverde','Rebecca Valverde'],needs_review=True,
         notes='The inscription prints 22 Menahem and year 5447; the quoted register prints 5442 [sic!] 22 Ab. The indexed date follows that register, with its uncertainty retained. No civil date is inferred.')
provenance(r,'IMG_1058.jpeg',[95,96]);metadata(r)

new_record(243,'Ester Gaon','Gaon','Ester',take(96,243,244).split('\n\nWorking towards Magazine Lane',1)[0],[96],'IMG_1058.jpeg',
    death_date='1666 [year supplied in book]',civil_year=1666,hebrew_date='5427 21 Tisri',hebrew_year=5427,
    inscription_language='Portuguese',aliases=['Ester Gaon','Esther Gaon'],needs_review=True,
    notes='The inscription is fragmentary. The quoted register supplies the month and the civil year in parentheses.')
new_record(244,'Unidentified memorial',None,'Unidentified memorial',take(96,244,245),[96],'IMG_1058.jpeg',
    needs_review=True,notes='The source describes the inscription as illegible; no name or date is supplied.')
new_record(245,'Deborah Burgos','Burgos','Deborah',take(96,245,246),[96],'IMG_1058.jpeg',
    inscription_language='Portuguese',needs_review=True,
    notes='Shilstone only tentatively associates this female inscription with a register entry for David Burgos, 23 Tisri 5448. That conflicting, possible identification is not assigned as Deborah’s confirmed death date and is excluded from yahrzeit matching.',
    date_basis='No securely associated death date; the proposed David Burgos register entry remains only in the source transcription.')
new_record(246,'Selomoh Tinoco','Tinoco','Selomoh',take(96,246,247),[96],'IMG_1058.jpeg',
    hebrew_date='5448 24 Kislev',hebrew_year=5448,inscription_language='Portuguese',
    aliases=['Selomoh Tinoco','Soloman Tinoca','Solomon Tinoco'],
    notes='The inscription spells the name Selomoh Tinoco; the quoted register reads Soloman Tinoca. Both spellings are searchable.')
new_record(247,'Rachel Ester Henriques','Henriques','Rachel Ester',take(96,247,248),[96],'IMG_1058.jpeg',
    hebrew_date='5448 11 Sebat',hebrew_year=5448,inscription_language='Portuguese, Hebrew',
    aliases=['Rachel Ester Henriques','Rahel Ester Henriques','Rachel Esther Henriques'])
new_record(248,'Aaron Gabay Risson','Gabay Risson','Aaron',take(96,248)+'\n'+pages['97'].split('\n\n249 ',1)[0],[96,97],'IMG_1058.jpeg',
    hebrew_date='5448 1 Yiar',hebrew_year=5448,inscription_language='Portuguese, Hebrew',
    aliases=['Aaron Gabay Risson','Aron Gabay Risson'],needs_review=True,
    notes='The incomplete inscription reads day 11 without a legible month; the quoted register gives 1 Yiar 5448. The indexed date follows the register.')
new_record(249,'Unidentified memorial',None,'Unidentified memorial',take(97,249,250),[97],'IMG_1058.jpeg',
    needs_review=True,notes='The source describes a broken, very worn memorial but supplies no name or date.')
new_record(250,'David Israel','Israel','David',take(97,250,251),[97],'IMG_1058.jpeg',
    hebrew_date='5449 21 Tamus',hebrew_year=5449,inscription_language='Portuguese, Hebrew',aliases=['David Israel','David Ysrael'],
    notes='The inscription’s month is printed TANVS; the quoted register reads Tamus. Historical spelling is retained.')
new_record(251,'Ephraim Yeshurun Henriques','Yeshurun Henriques','Ephraim',take(97,251,252),[97],'IMG_1058.jpeg',
    hebrew_date='5450 19 Tisri',hebrew_year=5450,inscription_language='Portuguese',
    aliases=['Ephraim Yeshurun Henriques','Ephaim Yesvrvn Henriques'],
    notes='The inscription prints EPHAIM YESVRVN; the quoted register spells the name Ephraim Yeshurun. Both forms are searchable.')
new_record(252,'Abraham de Medina','de Medina','Abraham',take(97,252,253),[97],'IMG_1058.jpeg',
    hebrew_date='5452 11 Nisan',hebrew_year=5452,inscription_language='Portuguese')
new_record(253,'Ester, daughter of Abraham and Rebecca',None,'Ester',take(97,253),[97],'IMG_1058.jpeg',
    hebrew_date='24 Iyar [year unclear]',hebrew_year=None,hebrew_name='אסתר בת אברהם ורבקה',
    relationships='Daughter of Abraham and Rebecca. No family surname is preserved in the photographed text.',
    inscription_language='Hebrew',aliases=['Ester daughter of Abraham and Rebecca','Esther daughter of Abraham and Rebecca'],needs_review=True,
    notes='The child’s name, parents and day 24 Iyar are legible. The final Hebrew year remains uncertain, and no numeric year or civil date has been inferred.',
    date_basis='Legible day and month in the Hebrew inscription; year unverified. Yahrzeit matches carry a review label.')

# Incorporate corrections visible in the overlapping photographs into both views.
for number, ps, filename in [(76,[42],'IMG_1057.jpeg'),(77,[42],'IMG_1057.jpeg'),(78,[43],'IMG_1057.jpeg'),(79,[43,44],'IMG_1057.jpeg'),(256,[101,102],'IMG_1059.jpeg'),(257,[102],'IMG_1060.jpeg'),(258,[102,103],'IMG_1060.jpeg'),(259,[103],'IMG_1060.jpeg'),(260,[103,104],'IMG_1060.jpeg')]:
    r=records['MI-'+str(number)]
    provenance(r,filename,ps)
    if number==77:r['transcription']=r['transcription'].replace('23 Septembr Judith','23 September Judith');r['death_date']='1759 23 September'
    if number==78:
        r['needs_review']=True
        r['notes']='The English inscription prints age 14 [?44]; the quoted register gives 44. The indexed age follows the register.'
    if number==79:r['transcription']=r['transcription'].replace('נונים שילדה','נוניש שילדה')
    if number==258:
        r['transcription']=r['transcription'].replace('De le bein /','De la bein /')
        r['inscription_language']='Spanish, English'
    if number==259:
        r['aliases']=list(dict.fromkeys(r['aliases']+['Joseph Jacob Lindo']))
        r['notes']='The English inscription gives 1793; the Portuguese text gives 15 Hesvan 5553 and 1793 [!]. The quoted register gives 5 Hesvan 5553 and 21 October 1792, with the name order Jacob Joseph. The indexed date follows the register; the conflicting source readings remain visible.'
    metadata(r)
provenance(records['MI-256'],'IMG_1060.jpeg',[101,102])

def link(a,b,relationship,basis):
    assert a in records and b in records
    if not any(x['id']==b for x in records[a]['cross_references']):
        records[a]['cross_references'].append({'id':b,'relationship':relationship,'basis':basis})
for wife,husband,basis in [
    ('MI-74','MI-fragment-42','M.I. 74 explicitly names David Aboab Furtado as Ester’s husband; M.I. 75 records that full name. A candidate memorial link, not an identity merge.'),
    ('MI-77','MI-76','M.I. 77 explicitly names Moses Haim Nunes Castello as Judith’s deceased husband; M.I. 76 records that full name. A candidate memorial link, not an identity merge.'),
    ('MI-258','MI-257','M.I. 258 explicitly names Isaac Israel de Piza as Rachel’s husband; M.I. 257 records that full name. A candidate memorial link, not an identity merge.')]:
    link(wife,husband,'Named husband · matching memorial',basis)
    link(husband,wife,'Named as husband in linked inscription',basis)

db['records']=sorted(records.values(),key=lambda r:(r['source_page'],r['id'].startswith('SH-'),int(re.match(r'\d+',r.get('monument_number') or '99999').group()),r['id']))
db['record_count']=len(db['records'])
assert db['record_count']==622
assert len({r['id'] for r in db['records']})==622
assert {r['id'] for r in old_records}.issubset(records)
assert all(x['id'] in records for r in db['records'] for x in r['cross_references'])
assert all(p in master['pages'] for p in master['order'])
assert len(master['order'])==len(set(master['order']))

html=original
for name,data in [('database',db),('masterData',master)]:
    pattern=r'(<script[^>]*id="'+name+r'"[^>]*>).*?(</script>)'
    encoded=json.dumps(data,ensure_ascii=False,indent=2).replace('</script','<\\/script')
    html=re.sub(pattern,lambda m:m.group(1)+encoded+m.group(2),html,count=1,flags=re.S)
old_coverage='Printed pages 40–41 and 96–97 are missing from the photographs and are marked as gaps.'
new_coverage=('The previously missing printed pages 40–41 and 96–97 were added from photographs supplied on 11 October 2026. '
              'An unnumbered illustration facing page 101 is included. No photographed page bears the number 99 or 100; '
              'their pagination remains unverified and is marked with editorial notices. Page 128 is recorded as blank.')
assert old_coverage in html
html=html.replace(old_coverage,new_coverage)
TEMPLATE.write_text(html)
(ROOT/'work/records.json').write_text(json.dumps(db,ensure_ascii=False,indent=2))
transcript=master['editorial_note']+'\n\n'.join('PAGE '+p.upper()+'\n'+master['pages'][p] for p in master['order'])+'\n'
(ROOT/'Shilstone_Master_Transcription_2026-10-11.txt').write_text(transcript)
report={'record_count_before':608,'record_count_after':622,'new_record_ids':sorted(set(records)-{r['id'] for r in old_records}),
        'updated_record_ids':[r['id'] for r in old_records if r != records[r['id']]],
        'filled_pages':[40,41,96,97],'pagination_unverified':[99,100],
        'old_fragment_promoted':{'id':'MI-fragment-42','monument_number':'75','source_pages':[41,42]},
        'new_named_records':12,'new_unidentified_memorials':2}
(ROOT/'work/missing-pages-20261011/recovery-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
