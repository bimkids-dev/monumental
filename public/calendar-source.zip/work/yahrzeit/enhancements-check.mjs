import fs from 'node:fs';
import http from 'node:http';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {HDate} from '@hebcal/core';
import {calendarAt,findUpcoming,findMatches} from './feature.mjs';
const require=createRequire(import.meta.url);
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
const path=new URL('../../Jewish_Barbados_Index.html',import.meta.url);
const html=fs.readFileSync(path,'utf8');
const originalHashes={"database": "6f206e8e9a7c79e5a5ba2d529ccfee22f7a911f68a86ffd82dfdeb0e4b53ee76", "masterData": "fc20ec2f6d5cd1b9366f19a891a194e0820a76484c83e9c9e9804e4d77a1961e"};
for(const id of ['database','masterData']) {
 const re=new RegExp('<script id="'+id+'"[^>]*>([\\s\\S]*?)<\\/script>');
 assert.equal(createHash('sha256').update(html.match(re)[1]).digest('hex'),originalHashes[id],id+' unchanged');
}
const records=JSON.parse(html.match(/<script id="database"[^>]*>([\s\S]*?)<\/script>/)[1]).records;
const today=calendarAt(new Date('2026-10-08T22:42:07Z')).hebrew;
const upcoming=findUpcoming(records,today);
assert.equal(upcoming.length,3);assert.equal(upcoming[0].hebrew.abs(),today.abs()+1);assert.equal(upcoming[2].hebrew.abs(),today.abs()+3);
for(const d of upcoming)assert.deepEqual(d.matches.map(m=>m.record.id),findMatches(records,d.hebrew).map(m=>m.record.id));
const boundary=findUpcoming([{id:'rosh',display_name:'Boundary',hebrew_date:'5700 1 Tishrei',hebrew_year:5700}],new HDate(29,6,5786));
assert.equal(boundary[0].hebrew.toString(),'1 Tishrei 5787');assert.equal(boundary[0].matches[0].record.id,'rosh');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(html)});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const url='http://127.0.0.1:'+server.address().port+'/index.html';
const browser=await chromium.launch({executablePath:'/tmp/nidhe-chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
try {
 const page=await browser.newPage({viewport:{width:1365,height:1100},timezoneId:'America/Barbados'});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  window.__testNow=Date.parse('2026-10-08T22:42:07Z');const RealDate=Date;
  window.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[window.__testNow]))}static now(){return window.__testNow}};
  Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async text=>{window.__copied=text}}});
 });
 await page.goto(url);
 assert(await page.locator('#nameVariants').isChecked());
 assert.equal(await page.locator('#total').innerText(),'608');
 assert.equal(await page.locator('#yahrzeitDate').innerText(),today.toString());
 assert.equal(await page.locator('#upcomingList [data-yahrzeit-record]').count(),upcoming.reduce((n,d)=>n+d.matches.length,0));
 assert(await page.locator('#indexView #remembrance').isVisible());
 assert(await page.locator('#remembrance').evaluate(e=>e.getBoundingClientRect().top<document.querySelector('.hero').getBoundingClientRect().top));
 assert.equal(await page.locator('#upcomingSection').evaluate(e=>e.open),false);
 assert(!(await page.locator('#upcomingList').isVisible()));
 const desktopPanelHeight=await page.locator('#yahrzeitSection').evaluate(e=>e.getBoundingClientRect().height);
 assert(desktopPanelHeight<180);
 await page.locator('#upcomingSection summary').focus();await page.keyboard.press('Enter');
 assert(await page.locator('#upcomingList').isVisible());assert.equal(await page.locator('.upcoming-day').count(),3);
 await page.keyboard.press('Enter');assert.equal(await page.locator('#upcomingSection').evaluate(e=>e.open),false);
 await page.screenshot({path:'work/yahrzeit/enhancements-desktop.png',fullPage:false});
 for(const route of ['history','reader','descendants','about']) {
  await page.locator('nav [data-view="'+route+'"]').click();
  assert(!(await page.locator('#remembrance').isVisible()));
  assert(await page.locator('#'+route+'View').isVisible());
 }
 for(const route of ['privacy','terms']) {
  await page.locator('footer [data-view="'+route+'"]').click();
  assert.equal(new URL(page.url()).hash,'#'+route);
  assert(await page.locator('#'+route+'View').isVisible());
  assert(!(await page.locator('#remembrance').isVisible()));
  assert.equal(await page.locator('main>section:visible').count(),1);
  assert.equal(await page.locator('footer [data-view="'+route+'"]').getAttribute('aria-current'),'page');
  assert.equal(await page.evaluate(()=>document.activeElement.id),route+'Title');
  await page.reload();assert(await page.locator('#'+route+'View').isVisible());
 }
 await page.goBack();assert(await page.locator('#privacyView').isVisible());
 await page.goForward();assert(await page.locator('#termsView').isVisible());
 await page.goto(url+'#privacy');await page.screenshot({path:'work/yahrzeit/privacy-desktop.png',fullPage:false});
 await page.locator('nav [data-view="descendants"]').click();await page.reload();
 assert(await page.locator('#descendantsView').isVisible());assert(!(await page.locator('#remembrance').isVisible()));
 assert.match(await page.locator('#descendantsView').innerText(),/no fixed generational cutoff/);
 assert.match(await page.locator('#descendantsView').innerText(),/Missing paperwork is not automatic disqualification/);
 assert.equal(await page.locator('#descendantsView a[href^="https://"]').count(),9);
 await page.screenshot({path:'work/yahrzeit/descendants-desktop.png',fullPage:true});
 await page.locator('nav [data-view="history"]').click();
 assert.equal(await page.locator('.timeline>li').count(),6);
 await page.screenshot({path:'work/yahrzeit/enhancements-history.png',fullPage:true});
 await page.locator('.timeline [data-read="v"]').first().click();assert.equal(await page.locator('#readerLabel').textContent(),'Page v');
 await page.locator('nav [data-view="index"]').click();
 async function search(q){await page.locator('#query').fill(q);await page.locator('#searchButton').click();return page.evaluate(()=>filtered.map(r=>r.id).sort())}
 for(const q of ['Meir','Meir aCohen Belinfante','Meir A-Cohen Belinfante','Mehir Acohen Belinfante','Meher Belinfante'])assert((await search(q)).includes('MI-322'),q+' should find the page 142 memorial');
 const castellos=await search('David Nunes Castello');assert(castellos.includes('MI-149')&&castellos.includes('MI-272'));
 await page.locator('#nameVariants').uncheck();await page.reload();assert(await page.locator('#nameVariants').isChecked());
 await page.locator('#reset').click();let belinfanteFamily;
 for(const name of ['A-Cohen Belinfante','Cohen Belinfante','Cohen Belinfanti']){
  await page.locator('#family').selectOption(name);const ids=await page.evaluate(()=>filtered.map(r=>r.id).sort());
  assert(ids.includes('MI-322')&&ids.includes('SH-181-05')&&ids.includes('MI-1'));
  if(belinfanteFamily)assert.deepEqual(ids,belinfanteFamily);else belinfanteFamily=ids;
 }
 await page.locator('#reset').click();
 const belinfante=await search('Belinfante'),belinfanti=await search('Belinfanti');assert.deepEqual(belinfante,belinfanti);assert(belinfante.length>=6);
 await page.locator('#nameVariants').uncheck();const exact=await search('Belinfante');assert.equal(exact.length,6);const exactBelinfanti=await search('Belinfanti');assert.equal(exactBelinfanti.length,1);
 await page.locator('#nameVariants').check();const louzada=await search('Louzada'),louzado=await search('Louzado'),lousada=await search('Lousada');assert.deepEqual(louzada,louzado);assert.deepEqual(louzada,lousada);
 await page.locator('#reset').click();assert.match(await page.locator('#appStatus').innerText(),/Filters reset/);
 await page.locator('#family').selectOption('Cohen Belinfante');assert((await page.evaluate(()=>filtered.map(r=>r.surname))).includes('Cohen Belinfanti'));
 await page.locator('#reset').click();
 await page.locator('#upcomingSection summary').click();
 const firstLink=page.locator('#upcomingList [data-yahrzeit-record]').first();const recordId=await firstLink.getAttribute('data-yahrzeit-record');
 await firstLink.click();assert.equal(new URL(page.url()).hash,'#record-'+recordId);assert(await page.locator('#recordDialog').isVisible());
 const recordTitle=await page.locator('#recordTitle').innerText();
 await page.locator('[data-copy="link"]').click();assert.equal(await page.evaluate(()=>window.__copied),page.url());
 await page.locator('[data-copy="citation"]').click();const citation=await page.evaluate(()=>window.__copied);assert(citation.includes(recordId)&&citation.includes('1988 edition')&&citation.includes(page.url())&&citation.includes('p. '));
 await page.reload();assert.equal(await page.locator('#recordTitle').innerText(),recordTitle);assert(await page.locator('#recordDialog').isVisible());
 await page.locator('#closeDialog').click();assert(!(await page.locator('#recordDialog').isVisible()));
 await page.locator('#upcomingSection summary').click();
 await page.locator('#upcomingList [data-yahrzeit-record]').first().click();
 await page.goBack();assert(!(await page.locator('#recordDialog').isVisible()));await page.goForward();assert(await page.locator('#recordDialog').isVisible());
 await page.evaluate(()=>{Object.defineProperty(navigator,'clipboard',{value:{writeText:async()=>{throw Error('denied')}}});document.execCommand=()=>false;});
 await page.locator('[data-copy="citation"]').click();assert(await page.locator('#copyFallback').isVisible());assert((await page.locator('#copyText').inputValue()).includes(recordId));assert.match(await page.locator('#copyStatus').innerText(),/selected below/);
 await page.keyboard.press('Escape');assert(!(await page.locator('#recordDialog').isVisible()));
 await page.goto(url+'#record-not-a-real-record');assert(await page.locator('#routeNotice').isVisible());assert(!(await page.locator('#recordDialog').isVisible()));
 await page.goto(url+'#home');await page.setViewportSize({width:390,height:844});await page.reload();
 assert(await page.locator('#yahrzeitSection').isVisible());
 const mobilePanelHeight=await page.locator('#yahrzeitSection').evaluate(e=>e.getBoundingClientRect().height);assert(mobilePanelHeight<260);
 assert.equal(await page.locator('#upcomingSection').evaluate(e=>e.open),false);
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 await page.screenshot({path:'work/yahrzeit/enhancements-mobile.png',fullPage:false});
 await page.locator('#upcomingSection summary').click();
 await page.locator('#upcomingList [data-yahrzeit-record]').first().click();assert.equal(await page.locator('#recordDialog').evaluate(e=>e.scrollWidth>e.clientWidth),false);
 await page.keyboard.press('Escape');await page.locator('nav [data-view="history"]').click();assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 await page.screenshot({path:'work/yahrzeit/enhancements-history-mobile.png',fullPage:true});
 await page.locator('nav [data-view="descendants"]').click();assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 await page.screenshot({path:'work/yahrzeit/descendants-mobile.png',fullPage:true});
 await page.locator('.descendants-search').click();assert.equal(new URL(page.url()).hash,'#home');
 for(const route of ['privacy','terms']) {
  await page.locator('footer [data-view="'+route+'"]').click();
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  assert(await page.locator('#'+route+'View').isVisible());
  assert(!(await page.locator('#remembrance').isVisible()));
 }
 await page.goto(url+'#privacy');await page.screenshot({path:'work/yahrzeit/privacy-mobile.png',fullPage:false});
 await page.locator('footer').scrollIntoViewIfNeeded();await page.screenshot({path:'work/yahrzeit/footer-mobile.png',fullPage:false});
 await page.goto('file://'+path.pathname+'#privacy');assert(await page.locator('#privacyView').isVisible());
 await page.locator('footer [data-view="terms"]').click();assert(await page.locator('#termsView').isVisible());
 await page.goto('file://'+path.pathname+'#record-MI-90');assert.equal(await page.locator('#recordTitle').innerText(),'Deborah Da Fonseca Valle');assert(await page.locator('.local-link-note').isVisible());
 await page.locator('#closeDialog').click();
 await page.locator('nav [data-view="index"]').click();
 await page.evaluate(()=>{window.__testNow=Date.parse('2026-10-07T21:44:12Z');window.dispatchEvent(new Event('focus'))});assert.equal(await page.locator('#yahrzeitDate').innerText(),'26 Tishrei 5787');
 const beforeRange=await page.locator('#upcomingRange').innerText();
 await page.evaluate(()=>{window.__testNow=Date.parse('2026-10-07T21:44:14Z');window.dispatchEvent(new Event('focus'))});assert.equal(await page.locator('#yahrzeitDate').innerText(),'27 Tishrei 5787');assert.notEqual(await page.locator('#upcomingRange').innerText(),beforeRange);
 await page.locator('#upcomingSection summary').click();
 await page.evaluate(()=>{NidheYahrzeit.mount([],openRecord)});assert(await page.locator('#upcomingEmpty').isVisible());assert.equal(await page.locator('#yahrzeitSummary').innerText(),'No recorded death dates match today’s Hebrew date.');
 assert.deepEqual(errors,[]);
 console.log('Privacy/terms: footer links, direct routes, reload, Back/Forward, keyboard focus, desktop/mobile layout and offline copy PASS');
 console.log(JSON.stringify({status:'PASS',records:records.length,panelHeight:{desktop:desktopPanelHeight,mobile:mobilePanelHeight},today:today.toString(),upcoming:upcoming.map(d=>({date:d.hebrew.toString(),matches:d.matches.length})),variantCounts:{belinfante:belinfante.length,exact:exact.length,louzada:louzada.length},checks:'Record data and master unchanged; compact home-only panels; collapsed keyboard-accessible three-day accordion; Hebrew new year and sunset rollover; variant search and family filter; permalink reload, Back/Forward, Escape, invalid link; clipboard and fallback; descendants route, sources and mobile layout; history and page references; offline HTML; no browser errors'}));
} finally {await browser.close();server.close();}
