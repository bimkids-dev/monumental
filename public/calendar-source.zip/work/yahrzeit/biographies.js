'use strict';
// Separately compiled biographies. Never mix these with the Shilstone source data.
const BIOGRAPHIES = JSON.parse(document.getElementById('biographyData').textContent);
const biographiesByRecord = new Map(BIOGRAPHIES.flatMap(b => b.recordIds.map(id => [id,b])));
const biographyHash = b => '#biography-' + b.slug;
function biographyFromRoute(hash) {
  if (!hash.startsWith('#biography-')) return null;
  let path; try { path=decodeURIComponent(hash.slice(11)); } catch (_) { return null; }
  const [slug,anchor=''] = path.split('/');
  const key = s => searchNorm(s).split(' ').map(t=>norm(variantLookup.get(t)?.[0]||t)).filter(t=>t!=='a').join(' ');
  const biography = BIOGRAPHIES.find(b=>b.slug===slug || [b.name,...b.aliases].some(n=>key(n)===key(slug)));
  return biography ? {biography,anchor:/^(?:note-\d+|ref-\d+-\d+)$/.test(anchor)?anchor:''} : null;
}
function biographyRecordLink(r) {
  const b=biographiesByRecord.get(r.id);
  return b ? '<aside class="biography-related"><h3>Biography</h3><p>Compiled separately; not part of E. M. Shilstone’s <em>Monumental Inscriptions</em>.</p><a href="'+biographyHash(b)+'" data-biography="'+biographyHash(b)+'">Read the biography of '+esc(b.name)+' →</a></aside>' : '';
}
function renderBiographyDirectory() {
  $('biographyDirectory').hidden=false; $('biographyArticle').hidden=true;
  $('biographyCards').innerHTML=BIOGRAPHIES.map(b=>'<article class="biography-card"><div><div class="eyebrow">'+esc(b.dates)+'</div><h2><a href="'+biographyHash(b)+'" data-biography="'+biographyHash(b)+'">'+esc(b.name)+'</a></h2><p>'+esc(b.summary)+'</p></div><a class="outlined" href="'+biographyHash(b)+'" data-biography="'+biographyHash(b)+'">Read biography →</a></article>').join('');
}
function renderBiography(b,anchor='') {
  $('biographyDirectory').hidden=true; $('biographyArticle').hidden=false;
  const base=biographyHash(b), refCounts=new Map(), refIds=new Map();
  const footnoteRefs = notes => notes.length ? '<span class="biography-references">'+notes.map(n=>{
    const count=(refCounts.get(n)||0)+1; refCounts.set(n,count);
    const id='ref-'+n+'-'+count; refIds.set(n,[...(refIds.get(n)||[]),id]);
    return '<sup><a id="'+id+'" href="'+base+'/note-'+n+'" data-biography="'+base+'/note-'+n+'" role="doc-noteref" aria-label="Footnote '+n+'">['+n+']</a></sup>';
  }).join('')+'</span>' : '';
  const part = p => esc(p.text)+footnoteRefs(p.notes||[]);
  const paragraphs=b.paragraphs.map(p=>{
    const html='<p>'+part(p)+(p.continuation?' '+part(p.continuation):'')+'</p>';
    return p.kind==='quote'?'<blockquote>'+html+'</blockquote>':html;
  }).join('');
  const sourceLink = l => l.record
    ? '<a href="'+recordHash(l.record)+'" data-record="'+esc(l.record)+'">'+esc(l.label)+'</a>'
    : l.page ? '<a href="#page-'+encodeURIComponent(l.page)+'" data-read="'+esc(l.page)+'">'+esc(l.label)+'</a>'
    : '<a href="'+esc(l.url)+'" target="_blank" rel="noopener noreferrer">'+esc(l.label)+' ↗</a>';
  const notes=b.footnotes.map(n=>'<li id="note-'+n.number+'" tabindex="-1"><strong>'+esc(n.title)+'.</strong> '+esc(n.text)+' '+n.links.map(sourceLink).join(' · ')+'<span class="biography-backrefs">'+(refIds.get(n.number)||[]).map((id,i)=>'<a href="'+base+'/'+id+'" data-biography="'+base+'/'+id+'" role="doc-backlink" aria-label="Return to reference '+(i+1)+' for footnote '+n.number+'">↩'+((refIds.get(n.number)||[]).length>1?i+1:'')+'</a>').join('')+'</span></li>').join('');
  $('biographyArticle').innerHTML='<a class="biography-back" href="#biographies" data-view="biographies">← All biographies</a><div class="biography-heading"><div class="eyebrow">Biography · Nidhe Israel</div><h1 id="biographyTitle" tabindex="-1">'+esc(b.name)+'</h1><p class="biography-dates">'+esc(b.dates)+'</p><p class="biography-aliases">Also recorded or searched as '+b.aliases.map(esc).join(' · ')+'</p><a class="outlined biography-record-link" href="'+recordHash(b.recordIds[0])+'" data-record="'+esc(b.recordIds[0])+'">View monumental inscription · M.I. '+esc(byId.get(b.recordIds[0])?.monument_number||b.recordIds[0])+'</a></div><p class="biography-separation">This biography was compiled separately and is not part of E. M. Shilstone’s <em>Monumental Inscriptions</em>.</p><p class="biography-editorial">Biography prepared '+esc(b.prepared)+'. '+esc(b.editorialNote)+'</p><div class="biography-body">'+paragraphs+'</div><section class="biography-notes" role="doc-endnotes" aria-labelledby="biographyNotesTitle"><h2 id="biographyNotesTitle">Footnotes & sources</h2><ol>'+notes+'</ol></section><p class="biography-attribution">'+esc(b.attribution)+'</p>';
  document.title=b.name+' · Biographies · Nidhe Israel';
  requestAnimationFrame(()=>{
    const target=anchor?$(anchor):$('biographyTitle');
    if(target && $('biographiesView').hidden===false && !$('recordDialog').open){
      if(anchor) {target.scrollIntoView({block:'start'});target.focus({preventScroll:true});}
      else window.scrollTo({top:0});
    }
  });
}
