'use strict';
const $ = id => document.getElementById(id);
window.addEventListener('error', () => { $('appStatus').textContent = 'The database could not finish loading. Please download a fresh copy and open the extracted HTML file in your browser.'; });
const DB = JSON.parse($('database').textContent), RECORDS = DB.records, MASTER = JSON.parse($('masterData').textContent);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm = s => String(s ?? '').normalize('NFKD').replace(/[\u0300-\u036f\u0591-\u05bd\u05bf-\u05c7]/g,'').toLowerCase().replace(/[^a-z0-9\u05d0-\u05ea]+/g,' ').trim();
// Search aids only: these groups do not establish a shared identity or kinship.
const NAME_VARIANTS = [
  ['Belinfante','Belinfanti','Belenfante'], ['Louzada','Louzado','Lousada'],
  ['Pereira','Pereyra'], ['Gomes','Gomez'], ['Levi','Levy'],
  ['Andrade','Andrada'], ['Piza','Peiza'], ['Risson','Rison'],
  ['Jeshurun','Jeshurum','Jessurun'], ['Burgos','Burgoss']
];
const variantLookup = new Map(NAME_VARIANTS.flatMap(group => group.map(name => [norm(name),group])));
const familyKey = s => norm(s).split(' ').map(t => norm(variantLookup.get(t)?.[0] || t)).join(' ');
const texts = RECORDS.map(r => norm(Object.values(r).map(v => typeof v === 'object' ? JSON.stringify(v) : v).join(' ')));
const byId = new Map(RECORDS.map(r => [r.id,r]));
let filtered = [], page = 0, currentRecord = null, readerPages = MASTER.order.slice(), readerPage = MASTER.order[0], variantOnly = new Set(), lastNonRecordRoute = '#home';
const pageSize = 30;
const routeNames = {index:'#home',reader:'#reader',history:'#history',descendants:'#descendants',about:'#about'};
const plainClick = e => e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey;
const recordHash = id => '#record-' + encodeURIComponent(id);
function recordURL(id) { const url = new URL(location.href); url.hash = recordHash(id); return url.href; }
function transcript(s) { return String(s || '').split('\n').map(l => '<div class="line'+(/[\u0590-\u05ff]/.test(l)&&!/[a-z]/i.test(l)?' heb':'')+'"'+(/[\u0590-\u05ff]/.test(l)&&!/[a-z]/i.test(l)?' dir="rtl" lang="he"':'')+'>'+esc(l)+'</div>').join(''); }
$('total').textContent = RECORDS.length;
[...new Set(RECORDS.map(r => r.surname).filter(Boolean))].sort((a,b) => a.localeCompare(b)).forEach(f => { const o = document.createElement('option'); o.value=f; o.textContent=f; $('family').append(o); });
function apply(reset = true) {
  if (reset) page = 0;
  const terms = norm($('query').value).split(' ').filter(Boolean), includeVariants = $('nameVariants').checked;
  const choices = terms.map(t => includeVariants && variantLookup.has(t) ? variantLookup.get(t).map(norm) : [t]);
  const family = $('family').value, kind = $('kind').value, cal = $('calendar').value;
  const from = $('fromYear').value === '' ? null : Number($('fromYear').value), to = $('toYear').value === '' ? null : Number($('toYear').value), review = $('review').checked;
  variantOnly = new Set();
  filtered = RECORDS.filter((r,i) => {
    if (!choices.every(group => group.some(t => texts[i].includes(t)))) return false;
    if (family && (includeVariants ? familyKey(r.surname) !== familyKey(family) : r.surname !== family)) return false;
    if (kind && r.record_type !== kind || review && !r.needs_review) return false;
    if (from !== null || to !== null) {
      const years = (r.date_values_as_printed || []).filter(y => cal === 'hebrew' ? y >= 5000 : y < 3000);
      if (!years.some(y => (from === null || y >= from) && (to === null || y <= to))) return false;
    }
    if (!terms.every(t => texts[i].includes(t)) || family && r.surname !== family) variantOnly.add(r.id);
    return true;
  });
  const sort = $('sort').value;
  filtered.sort((a,b) => sort === 'name' ? a.display_name.localeCompare(b.display_name) : sort === 'page' ? a.source_page-b.source_page || a.id.localeCompare(b.id,undefined,{numeric:true}) : (a[sort+'_year']??99999)-(b[sort+'_year']??99999) || a.display_name.localeCompare(b.display_name));
  const related = [...new Set(terms.flatMap(t => includeVariants ? (variantLookup.get(t)||[]).filter(v => norm(v)!==t) : []))];
  $('variantHint').textContent = related.length ? 'Also searching: '+related.join(', ')+'. Original spellings are preserved.' : includeVariants ? 'Includes selected spelling variants, such as Belinfante / Belinfanti and Louzada / Louzado / Lousada.' : 'Spelling variants are off. Search uses the text as transcribed.';
  render();
}
function render() {
  const pages = Math.max(1,Math.ceil(filtered.length/pageSize)); page = Math.min(page,pages-1);
  $('resultCount').textContent = filtered.length+' matching source records'+(filtered.length?' · '+(page*pageSize+1)+'–'+Math.min(filtered.length,(page+1)*pageSize):'')+(variantOnly.size?' · '+variantOnly.size+' via related spellings':'');
  $('rows').innerHTML = filtered.slice(page*pageSize,(page+1)*pageSize).map(r => '<tr><td><a class="name" href="'+recordHash(r.id)+'" data-record="'+esc(r.id)+'">'+esc(r.display_name)+'</a>'+(r.needs_review?'<span class="tag">Review</span>':'')+(variantOnly.has(r.id)?'<span class="tag variant-tag">Related spelling</span>':'')+'<span class="sub">'+esc(r.record_type)+(r.cross_references?.length?' · '+r.cross_references.length+' linked':'')+'</span></td><td>'+esc(r.death_date||'—')+'</td><td>'+esc(r.hebrew_date||'—')+'</td><td>'+esc(r.age||'—')+'</td><td><a class="sourcebtn" href="'+recordHash(r.id)+'" data-record="'+esc(r.id)+'">p. '+esc((r.source_pages||[r.source_page]).join(', '))+'</a><span class="sub">'+esc(r.monument_number?'M.I. '+r.monument_number:r.id)+'</span></td></tr>').join('');
  $('empty').hidden = filtered.length !== 0; $('prev').disabled = page === 0; $('next').disabled = page >= pages-1; $('pageCount').textContent = 'Page '+(page+1)+' of '+pages;
}
function view(v) {
  for (const t of ['index','reader','history','descendants','about']) $(t+'View').hidden = t !== v;
  document.querySelectorAll('nav [data-view]').forEach(a => { if (a.dataset.view === v) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current'); });
}
function navigate(hash, replace = false) {
  const from = location.hash.startsWith('#record-') ? history.state?.returnTo || lastNonRecordRoute : location.hash || '#home';
  if (location.hash !== hash) {
    try { history[replace?'replaceState':'pushState']({returnTo:from},'',hash); }
    catch (_) { if (replace) location.replace(hash); else location.hash=hash; }
  }
  applyRoute();
}
function openRecord(id) { if (byId.has(id)) navigate(recordHash(id)); }
function closeRecord() { navigate(history.state?.returnTo || lastNonRecordRoute || '#home',true); }
function citationFor(r) {
  const pages = [...new Set(r.source_pages || [r.source_page])];
  const reference = (pages.length > 1 ? 'pp. ' : 'p. ')+pages.join(', ')+(r.monument_number?', M.I. '+r.monument_number:'');
  const access = new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'long',year:'numeric'}).format(new Date());
  const link = /^https?:$/.test(location.protocol) ? recordURL(r.id) : 'Local HTML edition, '+recordHash(r.id);
  return 'E. M. Shilstone, Monumental Inscriptions in the Jewish Synagogue at Bridgetown, Barbados: With Historical Notes from 1630 (1988 edition), '+reference+'. “'+r.display_name+'.” Nidhe Israel — Names & Inscriptions, record '+r.id+'. '+link+' (accessed '+access+').';
}
function renderRecord(id) {
  const r = byId.get(id); currentRecord = r;
  $('recordLabel').textContent = (r.monument_number?'M.I. '+r.monument_number:r.id)+' · '+r.source_section;
  $('recordTitle').textContent = r.display_name;
  const fields = [['Civil date · as printed',r.death_date],['Hebrew date · as printed',r.hebrew_date],['Age · as printed',r.age],['Language',r.inscription_language],['Family lookup',r.surname],['Section',r.section],['Places mentioned',r.place_mentioned],['Birth / origin',r.place_of_birth_or_origin],['Hebrew name',r.hebrew_name]];
  $('recordBody').innerHTML = '<div class="record-tools"><button class="outlined" data-copy="link">Copy record link</button><button class="outlined" data-copy="citation">Copy citation</button><span class="sub">Record '+esc(r.id)+'</span></div><p class="copy-status sub" id="copyStatus" role="status" aria-live="polite"></p><div id="copyFallback" hidden><label for="copyText">Select and copy</label><textarea id="copyText" readonly rows="4"></textarea></div>'+(location.protocol==='file:'?'<p class="sub local-link-note">This is a local copy. Record links become shareable web links when you open the hosted site.</p>':'')+'<details class="citation-preview"><summary>View citation</summary><p>'+esc(citationFor(r))+'</p></details>'+(r.notes?'<div class="notice">'+esc(r.notes)+'</div>':'')+'<dl class="details">'+fields.filter(([k,v])=>v).map(([k,v])=>'<div><dt>'+esc(k)+'</dt><dd>'+esc(v)+'</dd></div>').join('')+'</dl><div class="pageactions">'+(r.source_pages||[r.source_page]).map(p=>'<button class="outlined" data-read="'+esc(p)+'">Read page '+esc(p)+'</button>').join('')+'</div>'+(r.cross_references?.length?'<h3>Cross-references</h3><div class="links">'+r.cross_references.map(c=>'<a class="outlined" href="'+recordHash(c.id)+'" data-record="'+esc(c.id)+'">'+esc(byId.get(c.id)?.display_name||c.id)+' · '+esc(c.relationship)+'<span class="relbasis">'+esc(c.id)+' · '+esc(c.basis)+'</span></a>').join('')+'</div>':'')+(r.relationships?'<details><summary>Recorded relationships & context</summary><p class="sub">'+esc(r.relationships)+'</p></details>':'')+'<h3>Complete source entry</h3><div class="recordtext transcript">'+transcript(r.transcription)+'</div><p class="sub" style="margin-top:25px">'+esc(r.date_basis||'Dates are retained as recorded in the appendix extract.')+'</p>';
  if (!$('recordDialog').open) $('recordDialog').showModal();
  $('recordDialog').scrollTop = 0;
}
async function copyRecordPart(kind) {
  if (!currentRecord) return;
  const id = currentRecord.id, value = kind === 'citation' ? citationFor(currentRecord) : recordURL(id);
  let copied = false;
  try { if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(value); copied = true; } } catch (_) {}
  if (currentRecord?.id !== id || !$('recordDialog').open) return;
  if (!copied) {
    $('copyFallback').hidden = false; $('copyText').value = value; $('copyText').focus(); $('copyText').select();
    try { copied = document.execCommand('copy'); } catch (_) {}
  }
  $('copyStatus').textContent = copied ? (kind === 'citation' ? 'Citation copied.' : 'Record link copied.') : 'Automatic copying is unavailable. The text is selected below; copy it using your browser or keyboard.';
  if (copied) $('copyFallback').hidden = true;
}
function pageOptions() {
  $('pageSelect').innerHTML = readerPages.map(p=>'<option value="'+esc(p)+'">'+esc(p.match(/^\d+$/)?'Page '+p:p)+'</option>').join('');
  if (!readerPages.includes(readerPage)) readerPage = readerPages[0];
  if (readerPage) { $('pageSelect').value = readerPage; readPage(readerPage); } else { $('pageText').textContent='No pages match this search.'; $('readerLabel').textContent='No matching pages'; }
  $('readerCount').textContent=readerPages.length+' matching page sections';
  $('pagePrev').disabled=!readerPages.length||readerPages.indexOf(readerPage)<=0; $('pageNext').disabled=!readerPages.length||readerPages.indexOf(readerPage)>=readerPages.length-1;
}
function readPage(p) {
  if (!(p in MASTER.pages)) return; readerPage=p; $('pageSelect').value=p; $('readerLabel').textContent='Page '+p; $('pageText').innerHTML=transcript(MASTER.pages[p]);
  $('pagePrev').disabled=readerPages.indexOf(p)<=0; $('pageNext').disabled=readerPages.indexOf(p)>=readerPages.length-1;
}
function goPage(p) { navigate('#page-'+encodeURIComponent(p)); $('readerView').scrollIntoView({behavior:'smooth',block:'start'}); }
function applyRoute() {
  const hash = location.hash || '#home'; let id;
  $('routeNotice').hidden = true;
  if (hash.startsWith('#record-')) {
    try { id = decodeURIComponent(hash.slice(8)); } catch (_) {}
    if (byId.has(id)) { view(lastNonRecordRoute.startsWith('#page-')?'reader':Object.keys(routeNames).find(k=>routeNames[k]===lastNonRecordRoute)||'index'); renderRecord(id); return; }
    $('routeNotice').textContent='This record link was not found. You can search the collection below.'; $('routeNotice').hidden=false;
  }
  if ($('recordDialog').open) $('recordDialog').close(); currentRecord=null;
  let v = Object.keys(routeNames).find(k => routeNames[k] === hash) || 'index';
  if (hash.startsWith('#page-')) {
    let p; try { p=decodeURIComponent(hash.slice(6)); } catch (_) {}
    if (p in MASTER.pages) { v='reader'; $('pageQuery').value=''; readerPages=MASTER.order.slice(); readerPage=p; pageOptions(); }
  }
  view(v); lastNonRecordRoute = hash.startsWith('#page-') && v === 'reader' ? hash : routeNames[v];
}
function download(name,type,text) { const u=URL.createObjectURL(new Blob([text],{type})), a=document.createElement('a'); a.href=u; a.download=name; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),1000); }
function csvText(rs) { const cols=['id','display_name','name_as_recorded','surname','surname_basis','death_date','hebrew_date','civil_year','hebrew_year','age','relationships','place_of_birth_or_origin','place_mentioned','inscription_language','section','monument_number','source_page','source_pages','record_type','notes','needs_review','cross_references','transcription','hebrew_transcription','source_urls']; const cell=v=>'"'+String(typeof v==='object'&&v!==null?JSON.stringify(v):v??'').replace(/"/g,'""')+'"'; return '\ufeff'+[cols.map(cell).join(','),...rs.map(r=>cols.map(k=>cell(r[k])).join(','))].join('\r\n'); }
document.addEventListener('click',e => {
  const target=e.target.closest('[data-record],[data-view],[data-read],[data-copy]');
  if (!target || !plainClick(e)) return;
  e.preventDefault();
  if (target.dataset.record) openRecord(target.dataset.record);
  else if (target.dataset.view) { navigate(routeNames[target.dataset.view]); window.scrollTo({top:0,behavior:'smooth'}); }
  else if (target.dataset.read) goPage(target.dataset.read);
  else if (target.dataset.copy) copyRecordPart(target.dataset.copy);
});
window.addEventListener('popstate',applyRoute); window.addEventListener('hashchange',applyRoute);
$('closeDialog').onclick=closeRecord;
$('recordDialog').addEventListener('cancel',e=>{e.preventDefault();closeRecord();});
$('recordDialog').addEventListener('click',e=>{if(e.target===$('recordDialog'))closeRecord();});
for (const id of ['fromYear','toYear']) $(id).addEventListener('input',()=>apply());
for (const id of ['family','calendar','kind','sort','review','nameVariants']) $(id).addEventListener('change',()=>apply());
$('prev').onclick=()=>{page--;render();}; $('next').onclick=()=>{page++;render();};
$('reset').onclick=()=>{ $('query').value=''; $('family').value=''; $('calendar').value='civil'; $('kind').value=''; $('sort').value='name'; $('fromYear').value=''; $('toYear').value=''; $('review').checked=false; $('nameVariants').checked=true; apply(); $('appStatus').textContent='Filters reset — '+RECORDS.length+' records ready to search.'; };
$('csv').onclick=()=>download('Jewish_Barbados_Search_Results.csv','text/csv;charset=utf-8',csvText(filtered)); $('json').onclick=()=>download('Jewish_Barbados_Index.json','application/json',JSON.stringify(DB,null,2));
$('pageQuery').oninput=()=>{const terms=norm($('pageQuery').value).split(' ').filter(Boolean); readerPages=MASTER.order.filter(p=>terms.every(t=>norm(MASTER.pages[p]).includes(t))); pageOptions();};
$('pageSelect').onchange=()=>readPage($('pageSelect').value); $('pagePrev').onclick=()=>readPage(readerPages[readerPages.indexOf(readerPage)-1]); $('pageNext').onclick=()=>readPage(readerPages[readerPages.indexOf(readerPage)+1]);
$('textExport').onclick=()=>download('Shilstone_Master_Transcription.txt','text/plain;charset=utf-8',MASTER.editorial_note+MASTER.order.map(p=>'PAGE '+p.toUpperCase()+'\n'+MASTER.pages[p]).join('\n\n'));
$('searchForm').onsubmit=e=>{e.preventDefault();apply();$('appStatus').textContent='Search complete: '+filtered.length+' matching records'+($('query').value.trim()?' for “'+$('query').value.trim()+'”.':'.');$('resultCount').scrollIntoView({behavior:'smooth',block:'center'});};
apply(); pageOptions(); applyRoute();
try { NidheYahrzeit.mount(RECORDS,openRecord); } catch(error) { $('yahrzeitSummary').textContent='The Hebrew calendar could not load. Please reload the downloaded file in your browser.'; console.error(error); }
$('searchButton').disabled=false; $('appStatus').textContent='Ready — '+RECORDS.length+' records loaded. Enter a name, then press Search or Enter.';
