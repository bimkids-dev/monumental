from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED,is_zipfile
import hashlib,shutil
root=Path(__file__).resolve().parents[2]
w=root/'work/yahrzeit'
# Retain the bundled calendar dependency sources and licences.
archives=[root/'Jewish_Barbados_Database.zip',root/'deploy/nidhe-israel/public/calendar-source.zip']
source_archive=next((p for p in archives if is_zipfile(p)),None)
if source_archive is None:raise RuntimeError('No complete calendar source archive is available')
with ZipFile(source_archive) as old:
    sources={n:old.read(n) for n in old.namelist() if n.startswith('work/yahrzeit/node_modules/')}
for name in ['feature.mjs','section.html','section.css','build.cjs','app.js','biographies.js','biographies.json','biographies.html','biographies.css','history.html','descendants.html','descendants.css','legal.html','legal.css','enhancements.css','check.mjs','browser-check.mjs','enhancements-check.mjs','package.json','package-lock.json','baseline/Jewish_Barbados_Index.html','package-deliverables.py','recover-missing-pages-20261011.py']:
    sources['work/yahrzeit/'+name]=(w/name).read_bytes()
readme='''NIDHE ISRAEL — SEARCHABLE DATABASE

Extract this ZIP and open Jewish_Barbados_Index.html in your browser.
Search, today's yahrzeits and the next three Hebrew days work offline.
The compact yahrzeit panels appear at the top of Home only.
Upcoming yahrzeits are in a collapsed accordion; click to open it. Dates follow Barbados
and change at calculated sunset in Bridgetown. Keep your device clock correct.

Open a record to copy its link or citation. A record link reopens that exact
entry, including when the page is refreshed. In a downloaded copy, links refer
to a local file; open the hosted site to copy public, shareable web links.

Name-variant search is on by default and can be switched off. The related
spellings help discovery; they do not prove a family relationship.
History & guide contains a short sourced timeline, glossary and research links.
Descendants discusses Sephardic ancestry in Barbados, slavery, intermarriage
and Conservative/Masorti Jewish status, with historical and rabbinic sources.
Biographies contains separately compiled life stories with numbered footnotes
and source links, beginning with Mehir aCohen Belinfante, linked from M.I. 322.
Biographies are not part of Shilstone’s source transcription.
Privacy Policy and Terms of Use are linked from the footer on every page.
These policies are drafts for testing until the public operator name and contact
email are confirmed. Hosting details should match the actual deployment.
The database contains 622 source records. All original 608 record IDs are retained.
Previously missing pages 40–41 and 96–97 are now transcribed. Fourteen records
were added (twelve named entries and two unidentified memorials), and the
existing David Aboab Furtado continuation is completed as M.I. 75.
Page numbers 99–100 remain unverified; the unnumbered plate facing 101 is included.
Uncertain readings and conflicting dates are marked; no year is invented.

The work/yahrzeit folder contains source and rebuild files.
To rebuild, run npm ci in that folder, then node build.cjs.
The main page template is baseline/Jewish_Barbados_Index.html; the application
is app.js; history is history.html; descendants is descendants.html;
calendar code is feature.mjs; policy text is legal.html.
Biographies are stored separately in biographies.json and rendered by biographies.js.
Add future biographies to that array with their own slug and linked recordIds.

Calendar code: Hebcal 5.9.0, GPL-2.0. Dependency sources and licences are included.
The software licence does not change rights in the historical source text.
'''
offline_temp=root/'Jewish_Barbados_Database.zip.tmp'
with ZipFile(offline_temp,'w',ZIP_DEFLATED) as z:
    z.write(root/'Jewish_Barbados_Index.html','Jewish_Barbados_Index.html')
    z.write(root/'Shilstone_Master_Transcription_2026-10-11.txt','Shilstone_Master_Transcription_2026-10-11.txt')
    z.writestr('READ_ME.txt',readme)
    for n,b in sources.items():z.writestr(n,b)
public=root/'deploy/nidhe-israel/public';public.mkdir(parents=True,exist_ok=True)
html=(root/'Jewish_Barbados_Index.html').read_text()
html=html.replace('<meta name="viewport"','<meta name="robots" content="noindex,nofollow"><meta name="viewport"',1)
html=html.replace('</head>','<!-- Calendar software sources and licences: calendar-source.zip -->\n</head>',1)
(public/'index.html').write_text(html)
with ZipFile(public/'calendar-source.zip','w',ZIP_DEFLATED) as z:
    z.writestr('READ_ME.txt',readme)
    for n,b in sources.items():z.writestr(n,b)
readme_path=public.parent/'README.txt'
s=readme_path.read_text()
s=s.replace('the next seven Hebrew days', 'the next three Hebrew days, in an accordion')
if 'Descendants page' not in s:
    s += '\nThe Descendants page covers Sephardic family history and Conservative/Masorti\nJewish status, with links to historical and rabbinic sources.\n'
s=s.replace('search and the automatic Barbados yahrzeit calendar.','search with name variants, permanent record links and citations, a history guide,\nand today\'s and upcoming yahrzeits (the next three Hebrew days) on Home only.')
s=s.replace('For updates, replace public/index.html with the updated HTML and commit.','For updates, replace public/index.html and public/calendar-source.zip with the\nfiles in this package and commit.')
if 'Privacy Policy and Terms of Use' not in s:
    s += '\nPrivacy Policy and Terms of Use are linked from the footer. They are drafts\nfor testing until the public operator name and contact email are confirmed.\nHosting details should match the actual deployment.\n'
readme_path.write_text(s)
render_temp=root/'Nidhe_Israel_Render_Test.zip.tmp'
with ZipFile(render_temp,'w',ZIP_DEFLATED) as z:
    for p in [public.parent/'render.yaml',readme_path,public/'index.html',public/'calendar-source.zip']:
        z.write(p,p.relative_to(public.parent))
# Confirm each package carries the intended bytes, and can be fully extracted.
with ZipFile(offline_temp) as z:
    assert z.testzip() is None
    assert z.read('Jewish_Barbados_Index.html')==(root/'Jewish_Barbados_Index.html').read_bytes()
with ZipFile(render_temp) as z:
    assert z.testzip() is None
    assert z.read('public/index.html')==(public/'index.html').read_bytes()
for temp,dest in [(offline_temp,root/'Jewish_Barbados_Database.zip'),(render_temp,root/'Nidhe_Israel_Render_Test.zip')]:
    if dest.exists():shutil.copystat(dest,temp)
    temp.replace(dest)
for f in ['Jewish_Barbados_Index.html','Jewish_Barbados_Database.zip','Nidhe_Israel_Render_Test.zip']:
    p=root/f;print(f,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
