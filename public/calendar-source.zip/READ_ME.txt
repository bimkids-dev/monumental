NIDHE ISRAEL — SEARCHABLE DATABASE

Extract this ZIP and open Jewish_Barbados_Index.html in your browser.
Search, today's yahrzeits and the next three Hebrew days work offline.
The compact yahrzeit panels appear at the top of Home only.
Upcoming yahrzeits are in a collapsed accordion; click to open it. Dates follow Barbados
and change at calculated sunset in Bridgetown. Keep your device clock correct.

Open a record to copy its link or citation. A record link reopens that exact
entry, including when the page is refreshed. In a downloaded copy, links refer
to a local file; open the hosted site to copy public, shareable web links.

Name-variant search is on by default and can be switched off. The related
spellings help discovery; they do not prove a family relationship.
History & guide contains a short sourced timeline, glossary and research links.
Descendants discusses Sephardic ancestry in Barbados, slavery, intermarriage
and Conservative/Masorti Jewish status, with historical and rabbinic sources.
Privacy Policy and Terms of Use are linked from the footer on every page.
These policies are drafts for testing until the public operator name and contact
email are confirmed. Hosting details should match the actual deployment.
The database contains 622 source records. All original 608 record IDs are retained.
Previously missing pages 40–41 and 96–97 are now transcribed. Fourteen records
were added (twelve named entries and two unidentified memorials), and the
existing David Aboab Furtado continuation is completed as M.I. 75.
Page numbers 99–100 remain unverified; the unnumbered plate facing 101 is included.
Uncertain readings and conflicting dates are marked; no year is invented.

The work/yahrzeit folder contains source and rebuild files.
To rebuild, run npm ci in that folder, then node build.cjs.
The main page template is baseline/Jewish_Barbados_Index.html; the application
is app.js; history is history.html; descendants is descendants.html;
calendar code is feature.mjs; policy text is legal.html.

Calendar code: Hebcal 5.9.0, GPL-2.0. Dependency sources and licences are included.
The software licence does not change rights in the historical source text.
